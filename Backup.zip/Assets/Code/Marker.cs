using UnityEngine;

[System.Serializable]
public struct Marker
{
    public Vector2 Position;
    public MarkerType Type;
    public Color32 Color;    
    public string Headline;
    public string Text;
    public string ImagePath;
}
