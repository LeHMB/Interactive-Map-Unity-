using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using System.IO;

public class ImageImporter : MonoBehaviour
{
    protected Texture2D texture;
    protected bool isLoaded = false;

    protected void LoadImage(string path)
    {
        string fullPath = Application.dataPath + path;
        if (File.Exists(fullPath))
        {
            byte[] byteArray = File.ReadAllBytes(fullPath);
            texture = new Texture2D(2, 2);
            isLoaded = texture.LoadImage(byteArray);
        }
        else isLoaded = false;
    }


    protected IEnumerator ImportImage(string path)
    {
        UnityWebRequest uwr = UnityWebRequest.Get(path);
        yield return uwr.SendWebRequest();

        byte[] byteArray = uwr.downloadHandler.data;
        texture = new Texture2D(2, 2);
        isLoaded = texture.LoadImage(byteArray);
    }
}
