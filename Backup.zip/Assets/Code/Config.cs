using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

[System.Serializable]
public struct Config
{
    public List<MarkerIcon> Icons;
    public float BaseZoom;
    public float ZoomStrengh;
    public Vector2 ZoomLimits;
    public Vector2 Boundaries;
}

[System.Serializable]
public struct MarkerIcon
{
    public string Name;
    public string Filename;
    public Vector2 Anchor;
}