using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.Timeline;
using UnityEngine.UI;


public enum MarkerType { Default, Cave, Circle, QuestionMark }

public class MarkerController : MonoBehaviour
{
    #region Singleton
    private static MarkerController instance;
    public static MarkerController Instance 
    { 
        get
        {
            return instance ? instance : instance = FindObjectOfType<MarkerController>();
        }
    }
    private void Awake()
    {
        // If there is an instance, and it's not me, delete myself.

        if (Instance != null && Instance != this)
        {
            Destroy(this);
        }
        else
        {
            instance = this;
            DontDestroyOnLoad(this.gameObject);
        }
    }
    #endregion


    public Texture2D image;

    //public List<Marker> markersTest = new List<Marker> ();
    public GameObject content;


    // Start is called before the first frame update
    void Start()
    {
        //Serialize(markersTest, Application.streamingAssetsPath + @"\test.xml" );

#if UNITY_EDITOR
        LoadMarkers(Application.dataPath + @"\Config\markers.xml");
#else
        ImportMarkers(ImportFile(@"Config\markers.xml"));
#endif

    }


    // Experimental reasons
    public static void Serialize(List<Marker> markers, string path)
    {
        XmlSerializer serializer = new XmlSerializer(markers.GetType());
        StreamWriter writer = new StreamWriter(path);
        serializer.Serialize(writer.BaseStream, markers);
        writer.Close();
    }

    public static List<Marker> DeserializeReader(StreamReader reader)
    {
        XmlSerializer serializer = new XmlSerializer(typeof(List<Marker>));        
        List<Marker> deserialized = (List<Marker>)serializer.Deserialize(reader.BaseStream);
        reader.Close();
        return deserialized;
    }

    public static List<Marker> DeserializeStream(MemoryStream stream)
    {
        XmlSerializer serializer = new XmlSerializer(typeof(List<Marker>));
        List<Marker> deserialized = (List<Marker>)serializer.Deserialize(stream);
        stream.Close();
        return deserialized;
    }

    void LoadMarkers(string path)
    {
        List<Marker> markers = DeserializeReader(new StreamReader(path));

        CreateMarkers(markers);
    }

    IEnumerator ImportMarkers(string path)
    {
        //string path = "Config/markers.xml"; //This works because index.html is in the same folder as StreamingAssets ?
        UnityWebRequest uwr = UnityWebRequest.Get(path);
        yield return uwr.SendWebRequest();

        List<Marker> markers = DeserializeStream(new MemoryStream(uwr.downloadHandler.data));

        CreateMarkers(markers);
    }

    private void CreateMarkers(in List<Marker> markers)
    {
        foreach (Marker marker in markers)
        {
            GameObject gameobj = Instantiate(Resources.Load("Marker") as GameObject);
            gameobj.transform.SetParent(this.content.transform, false);

            MarkerObject markerObj = gameobj.GetComponent<MarkerObject>();
            markerObj.pixelWordPos = marker.Position;
            markerObj.markerType = marker.Type;
            markerObj.markerColor = marker.Color;
            markerObj.headline.text = marker.Headline;
            markerObj.text.text = marker.Text;
            markerObj.text.ForceMeshUpdate(false, true);
            markerObj.descriptionImagePath = marker.ImagePath;
        }
    }

}
