using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(MarkerController))]
public class MarkerControllerEditor : Editor
{
    //SerializedProperty markersTest;
    SerializedProperty content;
    SerializedProperty image;

    void OnEnable()
    {
        //markersTest = serializedObject.FindProperty("markersTest");
        content = serializedObject.FindProperty("content");
        image = serializedObject.FindProperty("image");
    }

    public override void OnInspectorGUI()
    {
        serializedObject.Update();
        //EditorGUILayout.PropertyField(markersTest);
        EditorGUILayout.PropertyField(content);
        EditorGUILayout.PropertyField(image);
        serializedObject.ApplyModifiedProperties();
    }
}
